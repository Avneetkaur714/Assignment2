// constants for query selector

// function to change bg color from user input and add student id
function changeCustomColor() {

}

// function to change bg color from random no.
function changeRandomColor() {

}

// function to generate options for select list
function addList() {
    // Tip: you might have to check length condition so that the list does not keep growing when clicked
    // Tip: use createElement and appendChild inside every for loop to add elements to select list from array 
}

// function to change image
function changeImage() {

}

// event listeners for on click event of buttons and select

// event listeners for on change event of select